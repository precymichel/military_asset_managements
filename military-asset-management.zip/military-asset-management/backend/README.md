Backend (Node/Express) README
----------------------------

1. Install dependencies:
   ```bash
   cd backend
   npm install
   ```

2. Create a PostgreSQL database and run the SQL:
   ```bash
   psql -d mil_assets -f ../psql_dump.sql
   ```

3. Copy .env.example -> .env and edit DATABASE_URL and JWT_SECRET

4. Start the server:
   ```bash
   npm run dev
   ```

API endpoints (examples)
- POST /api/login  { username, password } -> { token, user }
- GET /api/assets  -> list assets
- POST /api/purchases { asset_id, quantity, description } -> create purchase
- POST /api/transfers { asset_id, from_base, to_base, quantity } -> create transfer
- POST /api/assign { asset_id, assigned_to, quantity } -> assign asset
- GET /api/dashboard -> simple aggregated view
