// Minimal static server to serve built frontend (for demo). In dev, you'll replace with create-react-app or similar.
const express = require('express');
const path = require('path');
const app = express();
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(3000, ()=> console.log('Frontend server on 3000'));
