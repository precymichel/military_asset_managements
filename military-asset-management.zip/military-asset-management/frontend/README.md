Frontend README
---------------
This is a minimal static frontend to demo functionality. In production replace with React (Create React App / Vite).

Run:
```bash
cd frontend
npm install
node server.js
# then open http://localhost:3000
```

The page uses the backend at http://localhost:4000. You can login with seeded users in psql_dump.sql.
